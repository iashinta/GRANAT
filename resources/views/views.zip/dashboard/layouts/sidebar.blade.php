<div class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                
                <li> 
                    <a href="{{url('home')}}" aria-expanded="false">
                        <i class="fa fa-dashboard"></i>
                        <span class="hide-menu">Dashboard</span></a>
                </li>

                <li> 
                 <a href="{{url('upload-berkas')}}" aria-expanded="false">
                        <i class="fa fa-file"></i>
                        <span class="hide-menu">Upload Berkas</span>
                    </a>
                </li>
                <li> 
                    <a href="{{url('logout')}}" aria-expanded="false">
                        <i class="fa fa-sign-out"></i>
                        <span class="hide-menu">Logout</span>
                    </a>
                </li>
                
            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</div>