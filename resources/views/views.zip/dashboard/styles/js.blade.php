<!-- All Jquery -->
<script src="{{asset('dashboard/js/lib/jquery/jquery.min.js')}}"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="{{asset('dashboard/js/lib/bootstrap/js/popper.min.js')}}"></script>
<script src="{{asset('dashboard/js/lib/bootstrap/js/bootstrap.min.js')}}"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="{{asset('dashboard/js/jquery.slimscroll.js')}}"></script>
<!--Menu sidebar -->
<script src="{{asset('dashboard/js/sidebarmenu.js')}}"></script>
<!--stickey kit -->
<script src="{{asset('dashboard/js/lib/sticky-kit-master/dist/sticky-kit.min.js')}}"></script>
<!--Custom JavaScript -->
<script src="{{asset('dashboard/js/custom.min.js')}}"></script>