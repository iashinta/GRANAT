@extends('dashboard.layouts.app')

@section('title','Dashboard')

@section('page-title','Pembayaran Registrasi Band Audition')

@section('dashboard-content')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body"><p>Pembayaran di transfer melalui Bank BRI sejumlah Rp.50.000,-<br>No. Rek 0248-01-024417-50-2 a.n. I Dewa Gede Wedrayana Kembar Suputra. Konfirmasi dan sertakan bukti pembayaran ke CP 082247819997.</p></div>
            </div>
        </div>
    </div>
    
@endsection
